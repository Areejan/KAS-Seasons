

public class Event extends Item{
	
	private String details;
	private String location;
	private int age;
	
	public Event(String name, String location, int age,DateTime date, double price, String details) {
		super(name, location, date, price);
		this.details = details;
		this.location = location;
		this.age = age;
	}
	

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Title: "+this.getName()+"\n"+
				"-->Location: "+this.location+"\n"+
				"-->Age restriction: "+this.age+"\n"+
				"-->Date: "+this.getDate().toString()+"\n"+
				"-->Price:"+this.getPrice();
	}


}
