public class Package extends Item{
	private String details;
	private int numOfTickets;
	private String residence;
	
	public Package(String name, String details, DateTime date, double price, int numOfTickets, String residence) {
		super(name, details, date, price);
		this.details = details;
		this.numOfTickets = numOfTickets;
		this.residence = residence;
	}


	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}



	public int getNumOfTickets() {
		return numOfTickets;
	}
	

	public void setNumOfTickets(int numOfTickets) {
		this.numOfTickets = numOfTickets;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Title: "+this.getName()+"\n"+
				"-->Details: "+this.getDetails()+"\n"+
				"-->Date: "+this.getDate()+"\n"+
				"-->Price: "+this.getPrice();
	}
}