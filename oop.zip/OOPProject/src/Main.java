import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {

	static LinkedList<User> users;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Prepare the data
		//Users, Events, Packages, Cities, DateTime
		
		
		//adding users
		users = new LinkedList<User>();
		users.add(new User("Areej","Hejji","hejjiar","Java1234","areej.hejji@gmail.com",911));
		users.add(new User("Lama","Sami","samila","Alula959","lama.sami@gmail.com",1111));
		users.add(new User("Mohammed","Miyad","miyad","1234","miyadma959@gmail.com",1111));
		
		
		//adding cities
		Item []OLA_EVENTS=new Event[4];
        OLA_EVENTS[0]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");
        OLA_EVENTS[1]=new Event("Maraya","Maraia Hall",10, new DateTime(2022,"November",18,8,30), 200,"details..");
        OLA_EVENTS[2]=new Event("Hegra After Dark","Awaken the senses Reception",10, new DateTime(2022,"November",18,8,30), 150,"details..");
        OLA_EVENTS[3]=new Event("Faia Yonan","Maraya Hall",18, new DateTime(2022,"November",18,8,30), 300,"details..");
        
        Item []Riyyadh_EVENTS=new Event[4];
        Riyyadh_EVENTS[0]=new Event("Riyadh Front","Airport Road",18, new DateTime(2022,"November",18,8,30), 0,"details..");
        Riyyadh_EVENTS[1]=new Event("Winter WinderLand"," AL GHADR ",10, new DateTime(2022,"November",18,8,30), 200,"details..");
        Riyyadh_EVENTS[2]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");
        Riyyadh_EVENTS[3]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");

        Item []Dammam_EVENTS=new Event[4];
        Dammam_EVENTS[0]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");
        Dammam_EVENTS[1]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");
        Dammam_EVENTS[2]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");
        Dammam_EVENTS[3]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");

        Item []Jeddah_EVENTS=new Event[4];
        Jeddah_EVENTS[0]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");
        Jeddah_EVENTS[1]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");
        Jeddah_EVENTS[2]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");
        Jeddah_EVENTS[3]=new Event("Music in Ancient","Winter Park",10, new DateTime(2022,"November",18,8,30), 198,"details..");

        
        Item[] alulaPackages =  new Package[3];
        alulaPackages[0] = new Package("Family", "for family",new DateTime(2022,"November",18,8,30), 2310,0,"Tarout");
        alulaPackages[1] = new Package("Singles", "for singles", new DateTime(2022,"November",18,8,30), 578,0,"Jubail");
        alulaPackages[2] = new Package("Twins", "for twins", new DateTime(2022,"November",18,8,30), 578,0,"Jubail");
        
        Item[] dammamPackages =  new Package[3];
        dammamPackages[0] = new Package("Family", "for family",new DateTime(2022,"November",18,8,30), 2310,0,"Tarout");
        dammamPackages[1] = new Package("Singles", "for singles", new DateTime(2022,"November",18,8,30), 578,0,"Jubail");
        dammamPackages[2] = new Package("Twins", "for twins", new DateTime(2022,"November",18,8,30), 578,0,"Jubail");
        
        Item[] riyadhPackages =  new Package[3];
        riyadhPackages[0] = new Package("Family", "for family",new DateTime(2022,"November",18,8,30), 2310,0,"Tarout");
        riyadhPackages[1] = new Package("Singles", "for singles", new DateTime(2022,"November",18,8,30), 578,0,"Jubail");
        riyadhPackages[2] = new Package("Twins", "for twins", new DateTime(2022,"November",18,8,30), 578,0,"Jubail");
        
        Item[] jeddehPackages =  new Package[3];
        jeddehPackages[0] = new Package("Family", "for family",new DateTime(2022,"November",18,8,30), 2310,0,"Tarout");
        jeddehPackages[1] = new Package("Singles", "for singles", new DateTime(2022,"November",18,8,30), 578,0,"Jubail");
        jeddehPackages[2] = new Package("Twins", "for twins", new DateTime(2022,"November",18,8,30), 578,0,"Jubail");
        
       City[] cities= new City[4];
       cities[0]=new City("AlUla",OLA_EVENTS,alulaPackages);
       cities[1]=new City("Riyadh",Riyyadh_EVENTS,dammamPackages);
       cities[2]=new City("Dammam",Dammam_EVENTS,riyadhPackages);
       cities[3]=new City("Jeddah",Jeddah_EVENTS,jeddehPackages);
		
       Ticket t = new Ticket();
		//scanner: print menu and take user input
		//do loop to ask the user to select events and packages and add any selected events/packages to the ticket object
		
       
		//starting the main program with the login method
       	//print welcome message
       
       //login
       	login();
       	
       	int choice;
		Scanner scanner = new Scanner(System.in);
       	//-->print list of citites
		do
		{
	       	System.out.println("Please select a City:");
	       	for(int i=0;i<cities.length;i++) {
	       		System.out.println((i+1)+"- "+cities[i].getname());
	       	}
	       	
	       	try {
	       		choice = scanner.nextInt();
	       	}catch(Exception e) {
	       		scanner.next();
	       		choice = -1;
	       	}
	       	if(choice < 1 || choice>cities.length)
	       	{
	       		System.out.println("You selected an invalid choice. please try again.");
	       	}
	       	else
	       		break;
		}while(true);
		
		
		int city_index = choice-1;
       	System.out.println("Great!, now please select an event in "+cities[city_index].getname()+":");
       	
       	
		boolean done = false;
		do {
			do {
				//show the list of events of the selected citiy
				for(int i=0;i<cities[(city_index)].getEvents().length;i++) {
					System.out.println((i+1)+"-"+cities[(city_index)].getEvents()[i].toString());
				}
				try {
					choice = scanner.nextInt();
				}catch(Exception e) {
					scanner.next();
					choice = -1;
				}
		       	if(choice < 1 || choice>cities[city_index].getEvents().length)
		       	{
		       		System.out.println("You selected an invalid choice. please try again.");
		       	}
		       	else
		       		break;
			}while(true);
		       	
	       	int event_index = choice-1;
	       	
	       	//add the event to the ticket object
	       	t.addEvent(cities[city_index].getEvents()[event_index]);
	       	
	       	do {
		       	System.out.println("Would like to buy/book another event?");
		       	System.out.println("1. Yes");
		       	System.out.println("2. No");
		       	try {
		       		choice = scanner.nextInt();
		       	}catch(Exception e) {
		       		scanner.next();
		       		choice = -1;
		       	}
		       	if(choice == 2) {
		       		done = true;
		       		break;
		       	}
		       	else if (choice == 1) {
		       		done = false;
		       		break;
		       	}
		       	else {
		       		System.out.println("Please select a valid option!");
		       	}
	       	}while(true);
	       	
		}while(!done);
       	
       	
		//to reuse the same variable instead of creating a new one
		done = false;
       	do {
       		System.out.println("We have also a list of packages for your to save money, interested?");
           	System.out.println("1. Yes");
           	System.out.println("2. No");
           	try {
           		choice = scanner.nextInt();
           	}catch(Exception e) {
           		scanner.next();
           		choice = -1;
           	}
	       	if(choice ==  1) {
	       		//show packages
	       		System.out.println("Nice, please select one of these packages in "+cities[city_index].getname()+":");
	       		Item[] packages = cities[city_index].getPackages();
	       		do {
		       		for(int i=0;i<packages.length;i++) {
		       			System.out.println((i+1)+"-"+packages[i].toString());
		       		}
		       		try {
		       			choice = scanner.nextInt();
		       		}catch(Exception e) {
		       			scanner.next();
		       			choice = -1;
		       		}
		       		//validity check
		       		if(choice>0 && choice <= packages.length)
		       		{
		       			//valid choice
		       			System.out.println("Excellent choice!");
		       			t.addPackage(cities[city_index].getPackages()[(choice-1)]);
		       			done = true;
		       			break;
		       		}
		       		else {
		       			//invalid choice
		       			System.out.println("You selected an invalid choice. please try again!");
		       		}
	       		}while(true);
	       	}
	       	else if (choice == 2) {
	       		break;
	       	}
	       	else {
	       		System.out.println("Please select a valid option!");
	       	}
       	}while(!done);
       	
       	System.out.println("Thank you for choosing us. Below please find the details of your invoice:");
       	System.out.println("------------------");
       	System.out.println("List of selected events:");
       	for(Item e:t.getEvents()) {
       		System.out.println(e);
       	}
       	System.out.println("------------------");
       	System.out.println("Selected package:");
       	for(Item p:t.getPackages()) {
       		System.out.println(p);
       	}
       	System.out.println("------------------");
       	System.out.println("Total price:"+t.price());
       	
       	
       	

	}
	
	public static void login() {
		int choice;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Welcome to ...");
		
        
        
        do {
        	System.out.println("Please select an option:");
            System.out.println("1. login");
            System.out.println("2. register");
            try {
        	choice = scanner.nextInt();
            } catch(InputMismatchException e) {
            	//this means user entered an invalid option
            	System.out.println("Invalid option! please try again");
            	scanner.next();
            	continue;
            }
        	//to clean the line
        	scanner.nextLine();
        	if(choice == 1) {
        		System.out.println("Enter your username:");
                String Luser = scanner.nextLine();
                System.out.println("No enter your Password:");
                String Lpassword = scanner.nextLine();
                if(!login(Luser, Lpassword)) {
                	System.out.println("Invalid username or passwoard!.. ");
                }else {
                	System.out.println("Login successfull!");
                	break;
                }
        	}
        	else if (choice == 2) {
        		register(scanner);
        		//break;
        	}
        	else {
        		System.out.println("Invalid option! please try again");
        	}
        	
        }while(true);


	}
	
	public static boolean login(String username,String pass) {
		
		for(User user:users) {
			if(user.getUserName().equals(username) && user.getPassword().equals(pass))
				return true;
		}
		return false;
		
	}
	
	public static void register(Scanner scanner) {
	        User newUser = new User();
	        
	        try
	        {
			System.out.print("Enter firstName => ");
	        String firstName = scanner.nextLine();
	        newUser.setFirstName(firstName);
	
	        System.out.print("Enter lastName => ");
	        String lastName = scanner.nextLine();
	        newUser.setLastName(lastName);
	
	        System.out.print("Enter userName => ");
	        String userName = scanner.nextLine();
	        newUser.setUserName(userName);
	
	        System.out.print("Enter password => ");
	        String password = scanner.nextLine();
	        newUser.setPassword(password);
	
	        System.out.print("Enter emailId => ");
	        String emailId = scanner.nextLine();
	        newUser.setEmailId(emailId);
	
	        System.out.print("Enter phoneNo => ");
	        long phoneNo = scanner.nextLong();
	        newUser.setPhoneNo(phoneNo);
	        }catch (Exception e) {
	        	scanner.next();
	        	System.out.println("You entered an invalid data!");
	        	return;
	        }
	       
	        System.out.println("Registeration is successfull. Now please login.");
	        users.add(newUser);
	        
	}

}
