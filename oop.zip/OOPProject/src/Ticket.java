import java.util.LinkedList;

public class Ticket {
	
	private LinkedList<Item> events;
	private LinkedList<Item> packages;
	
	public Ticket() {
		events = new LinkedList<Item>();
		packages = new LinkedList<Item>();
	}
	
	public void addEvent(Item e) {
		this.events.add(e);
	}
	
	public void addPackage(Item p) {
		this.packages.add(p);
	}
	
	public LinkedList<Item> getEvents() {
		return events;
	}
	public LinkedList<Item> getPackages() {
		return packages;
	}
	
	public double price() {
		double total = 0;
		for(Item e: events) {
			total += e.getPrice();
		}
		for(Item p:packages) {
			total += p.getPrice();
		}
		
		return total;
	}

}
