import java.util.Date;

public class Package extends Item{
	private String details;
	private int numOfTickets;
	private String residence;
        private String city;
	
	public Package(String name, String details, Date date, double price, int numOfTickets, String residence,String city) {
		super(name, details, date, price);
		this.details = details;
		this.numOfTickets = numOfTickets;
		this.residence = residence;
                this.city = city;
	}

    public String getResidence() {
        return residence;
    }

    public void setResidence(String residence) {
        this.residence = residence;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }


	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}



	public int getNumOfTickets() {
		return numOfTickets;
	}
	

	public void setNumOfTickets(int numOfTickets) {
		this.numOfTickets = numOfTickets;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Title: "+this.getName()+"\n"+
				"-->Details: "+this.getDetails()+"\n"+
				"-->Date: "+this.getDate()+"\n"+
				"-->Price: "+this.getPrice();
	}
}