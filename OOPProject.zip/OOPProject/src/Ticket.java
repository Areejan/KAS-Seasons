import java.util.LinkedList;

public class Ticket {
	
	private String username;
	private LinkedList<TicketItem> items;
	
	public Ticket(String username) {
            this.username = username;   
            items = new LinkedList<TicketItem>();
	}

    Ticket() {
        items = new LinkedList<TicketItem>();
    }

    

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public LinkedList<TicketItem> getItems() {
        return items;
    }

    public void setItems(LinkedList<TicketItem> items) {
        this.items = items;
    }
    
    public void addItem(TicketItem item) {
        items.add(item);
    }
        
        

    public double totalPrice() {
            double total = 0;
            for(TicketItem i: items) {
                    total += i.getPrice();
            }
            return total;
    }

}
