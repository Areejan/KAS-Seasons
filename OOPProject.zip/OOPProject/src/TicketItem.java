
import java.util.Date;

//parent class or super class 
public class TicketItem {

	private String type;
        private String detail;
	private double price;	

	public TicketItem(String type, String detail,double price) {
		this.type = type;
                this.detail = detail;
		this.price = price;
	}

    TicketItem() {
  
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }
    
    
	
	
       
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	

}
