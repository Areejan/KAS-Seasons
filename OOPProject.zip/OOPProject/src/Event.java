
import java.util.Date;

//chiled class or sub class

public class Event extends Item{
	
	private String details;
	private String location;
	private int age;
        private String time;
	
	public Event(String name, String location, int age,Date date, double price, String details,String time) {
		super(name,location, date, price);
		this.details = details;
		this.location = location;
		this.age = age;
                this.time = time;
	}

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
	
        
	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Title: "+this.getName()+"\n"+
				"-->Location: "+this.location+"\n"+
				"-->Age restriction: "+this.age+"\n"+
				"-->Date: "+this.getDate().toString()+"\n"+
				"-->Price:"+this.getPrice();
	}


}
