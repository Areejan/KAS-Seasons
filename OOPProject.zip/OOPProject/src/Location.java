/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author areej
 */
public class Location {
    private String region ;
    private String city;

    public Location(String region, String city) {
        this.region = region;
        this.city = city;
    }

    @Override
    public String toString() {
        return "Location{" + "region=" + region + ", city=" + city + '}';
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    
}
