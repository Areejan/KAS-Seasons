
public class City {
private String city_name;
private Item [] events;
private Item [] packages;


public City(String name,Item [] events, Item[] packages){
    this.city_name=name;
    this.events=events;
    this.packages = packages;
}
   public City() {
        this.city_name="";
        this.events= new Event[4];
        this.packages = new Package[3];
    }
    
public void setname(String name){
    this.city_name=name;
    }

public void setEvents(Event[] events ){
    this.events=events;
    }

public Item[] getEvents() {
    return events;
    }

public Item[] getPackages() {
	return packages;
}
public void setPackages(Package[] packages) {
	this.packages = packages;
}

public String getname()
{return city_name;}

public void printEvents(){
        for (int i =0 ; i<this.events.length;i++){
            System.out.println(events[i].toString());
            System.out.println("-----------------------------");
        }
    }//we use .length rether than write the index

@Override
 public String toString() {
        return this.city_name + "\n"  ;
 }
}
