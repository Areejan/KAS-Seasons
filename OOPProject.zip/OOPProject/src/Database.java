import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LAMA
 */
public class Database {

    final private int PORT = 3306;
    final private String DB_NAME = "ksa_season";
    final private String DB_USER = "root";
    final private String DB_PASS = "areejan";
    final private String DATABASE_URL = "jdbc:mysql://localhost:"+PORT+"/"+DB_NAME;
    private Statement statement = null;
    
    
    
    public void connect(){
        try {
            //Class.forName("com.mysql.jdbc.Driver");
            //Class.forName("org.gjt.mm.mysql.Driver");
            Connection connection = DriverManager.getConnection(
                        DATABASE_URL, DB_USER, DB_PASS);       
            statement = connection.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public ResultSet executeSQL(String sql){
        
        try {
            if(statement.isClosed())
                return null;
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        ResultSet resultSet = null;
        
        try {
            resultSet = statement.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return resultSet;
        
    }
    
    public Object executeUpdateSQL(String sql){
        
        try {
            if(statement.isClosed())
                return null;
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
                
        try {
            statement.executeUpdate(sql,Statement.RETURN_GENERATED_KEYS);
            ResultSet rs = statement.getGeneratedKeys();
            if(rs.next()){
                //System.out.println(rs.getObject(1));
                return rs.getObject(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
        
    }
    
    public static void main(String[] args){
        Database db = new Database();
        db.connect();
        int id = Integer.parseInt(db.executeUpdateSQL("insert into tickets_table(username) values('lama')").toString());
        System.out.println(id);
    }
    
}