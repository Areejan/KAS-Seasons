
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author areej
 */
public class DBInterface {
    
    private Database db;
    public DBInterface(){
        db = new Database();
        db.connect();
    }
    
    public List<Package> loadPackages() throws SQLException{
        
        List<Package> list = new ArrayList<Package>();
        String sql = "select * from package_table as p  join location_table as l on p.location = l.code_location";
        ResultSet result = db.executeSQL(sql);
        ResultSetMetaData meta = result.getMetaData();
    
        while(result.next()){
            String name = result.getObject("pack_name").toString();
            String details = result.getObject("details").toString();
            String hotel = result.getObject("hotel").toString();
            int price = result.getInt("price");
            String city = result.getString("city");

            Package p = new Package(name,details,null,price,0,hotel,city);
            list.add(p);
        }
        
        return list;
    }
    
   
        
    
    public List<Event> loadِEvents() throws SQLException{
        
        List<Event> list = new ArrayList<Event>();
        String sql = "select * from event_table as e  join location_table as l on e.code_location_fk = l.code_location;";
        System.out.println(sql);
        ResultSet result = db.executeSQL(sql);
        ResultSetMetaData meta = result.getMetaData();
        while(result.next()){
            String name = result.getString("event_name");
            String details = "";//result.getObject("details").toString();
            int age = result.getInt("age");
            int price = result.getInt("event_price");
            String city = result.getString("city");
            Date date = result.getDate("event_date");
            String time = result.getString("event_time");

            Event e = new Event(name,city,age,date,price,details,time);
            list.add(e);
        }
        
        return list;
    }
    
    
    public List<Location> loadLocation() throws SQLException{
        
        List<Location> list = new ArrayList<Location>();
        String sql = "select * from location_table ";
        ResultSet result = db.executeSQL(sql);
        ResultSetMetaData meta = result.getMetaData();
        while(result.next()){
            String region = "";//result.getString("region");
            String city = result.getString("city");

            Location l = new Location(region,city);
            list.add(l);
        }
        
        return list;
    }
    
    public Ticket loadTicket(int ticketId) throws SQLException{
        String sql = "SELECT * FROM ksa_season.tickets_table as t  join ksa_season.items_table as i on t.ticket_id = i.ticket_id_fk where ticket_id ="+ticketId+";";
        ResultSet result = db.executeSQL(sql);
        Ticket ticket = new Ticket();
        String username = "";
        while(result.next()){
            TicketItem item = new TicketItem();
            item.setType(result.getString("item_type"));
            item.setDetail(result.getString("item_detail"));
            item.setPrice(result.getDouble("price"));
            username = result.getString("username");
            ticket.addItem(item);
        }
        ticket.setUsername(username);
        
        return ticket;
    }
    
    
    
    public Integer createTicket(Ticket t) throws SQLException{
        
        //1. insert ticket
        String sql = "INSERT INTO Tickets_Table(username) VALUES('"+t.getUsername()+"');";
        int ticketId = Integer.parseInt(db.executeUpdateSQL(sql).toString());
        //2. insert items
        for(TicketItem item: t.getItems()){
            sql = "INSERT INTO Items_Table(item_type,price,ticket_id_fk,item_detail) VALUES('"
                    +item.getType()+"',"
                    +item.getPrice()+","
                    +ticketId+",'"
                    +item.getDetail()+"');";
            db.executeUpdateSQL(sql);
        }
        
        return ticketId;
        
    }
    
    /**
     * name: login
     * parameters:
     * * usernaem of type string
     * * password of type string
     * return type: boolean
     * 
     * verify if username and password exisit in database: true if yes, otherwise false
     * @param username
     */
    public boolean  login (String username , String password ) throws SQLException{
       boolean found = false;
       String sql = "select * from user_table where username=\""+username+"\" and password_user=\""+password+"\"";
       ResultSet result = db.executeSQL(sql); // execute the queray
       System.out.println(sql);
      
       ResultSetMetaData meta = result.getMetaData(); // view the infOrmation of DB
       while(result.next()){
           found = true;// check the data in the table 
           break; // found
       }
      
       return found; // not found

    }
    
    //for testing only
    public static void main(String [] areej ){
        
        DBInterface di= new DBInterface();
        /*
       // THIS CODE IS TO MADE SURE EXECUTE IS CORRECT
        try {
        List<Package> pk = di.loadPackages();
        for(Package p:pk){
        System.out.print(p);
        }            
        } catch (SQLException ex) {
        Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
         */
        /*
        try {
        List<Event> events = di.loadِEvents();
        for(Event e:events){
        System.out.print(e);
        }
        } catch (SQLException ex) {
        Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
         */
        /*
        try {
        List<Location> location = di.loadLocation();
        for(Location l:location){
        System.out.print(l);
        }
        } catch (SQLException ex) {
        Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
         */
        //System.out.println(di.login("JOK1234", "564537"));
        
    }
    
}
