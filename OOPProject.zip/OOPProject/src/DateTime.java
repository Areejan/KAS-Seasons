
public class DateTime {
	
	private int year;
	private String month;
	private int day;
	private int hour;
	private int minute;

	public DateTime(int year, String month, int day, int hour, int minute) {
		// TODO Auto-generated constructor stub
		this.year = year;
		this.month = month;
		this.day = day;
		this.hour = hour;
		this.minute = minute;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return year + "," + month + "," + day+","+hour+":"+minute;
	}

}
